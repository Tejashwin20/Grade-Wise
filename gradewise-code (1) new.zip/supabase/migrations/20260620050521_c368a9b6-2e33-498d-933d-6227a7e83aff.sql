REVOKE EXECUTE ON FUNCTION public.handle_new_user() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.update_updated_at_column() FROM PUBLIC, anon, authenticated;

CREATE POLICY "Teachers upload own answer sheets" ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'answer-sheets' AND auth.uid()::text = (storage.foldername(name))[1]);
CREATE POLICY "Teachers read own answer sheets" ON storage.objects FOR SELECT TO authenticated
  USING (bucket_id = 'answer-sheets' AND auth.uid()::text = (storage.foldername(name))[1]);
CREATE POLICY "Teachers delete own answer sheets" ON storage.objects FOR DELETE TO authenticated
  USING (bucket_id = 'answer-sheets' AND auth.uid()::text = (storage.foldername(name))[1]);