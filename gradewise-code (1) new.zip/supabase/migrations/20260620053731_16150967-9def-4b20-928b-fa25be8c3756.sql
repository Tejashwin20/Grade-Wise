CREATE POLICY "Teachers update own answer sheets"
ON storage.objects
FOR UPDATE
TO authenticated
USING ((bucket_id = 'answer-sheets'::text) AND ((auth.uid())::text = (storage.foldername(name))[1]))
WITH CHECK ((bucket_id = 'answer-sheets'::text) AND ((auth.uid())::text = (storage.foldername(name))[1]));