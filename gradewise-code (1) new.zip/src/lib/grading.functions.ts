import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const GATEWAY_URL = "https://ai.gateway.lovable.dev/v1/chat/completions";
const MODEL = "google/gemini-2.5-flash";

interface CriterionScore {
  name: string;
  score: number;
  max: number;
  comment: string;
}

interface GradeResult {
  extracted_text: string;
  score: number;
  feedback: string;
  criteria: CriterionScore[];
}

function mimeFromPath(path: string): string {
  const ext = path.split(".").pop()?.toLowerCase();
  if (ext === "png") return "image/png";
  if (ext === "jpg" || ext === "jpeg") return "image/jpeg";
  if (ext === "webp") return "image/webp";
  if (ext === "pdf") return "application/pdf";
  return "application/octet-stream";
}

async function gradeAnswer(
  apiKey: string,
  params: {
    prompt: string;
    modelAnswer: string | null;
    rubric: string | null;
    maxMarks: number;
    answerText: string | null;
    fileData?: { base64: string; mime: string };
  },
): Promise<GradeResult> {
  const system = `You are an impartial exam grader. Evaluate the student's answer strictly against the provided model answer and rubric. Be fair, consistent, and free of bias. Award partial credit where deserved. Always respond with a JSON object only, matching this shape:
{
  "extracted_text": string,      // the student's answer text (transcribe from image/PDF if provided, else echo the typed answer)
  "score": number,               // total awarded marks for this question, between 0 and ${params.maxMarks}
  "feedback": string,            // constructive, specific feedback for the student (2-4 sentences)
  "criteria": [ { "name": string, "score": number, "max": number, "comment": string } ]
}
If no rubric criteria are given, derive 2-4 sensible criteria from the model answer. The sum of criteria scores should equal "score".`;

  const userText = `QUESTION:\n${params.prompt}\n\nMODEL ANSWER:\n${
    params.modelAnswer || "(none provided — judge against the question and good academic standards)"
  }\n\nRUBRIC:\n${params.rubric || "(none provided)"}\n\nMAXIMUM MARKS: ${params.maxMarks}\n\n${
    params.fileData
      ? "The student's answer is in the attached file. Transcribe it, then grade it."
      : `STUDENT ANSWER:\n${params.answerText || "(blank)"}`
  }`;

  const content: unknown[] = [{ type: "text", text: userText }];
  if (params.fileData) {
    if (params.fileData.mime === "application/pdf") {
      content.push({
        type: "file",
        file: {
          filename: "answer.pdf",
          file_data: `data:application/pdf;base64,${params.fileData.base64}`,
        },
      });
    } else {
      content.push({
        type: "image_url",
        image_url: { url: `data:${params.fileData.mime};base64,${params.fileData.base64}` },
      });
    }
  }

  const res = await fetch(GATEWAY_URL, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Lovable-API-Key": apiKey,
    },
    body: JSON.stringify({
      model: MODEL,
      response_format: { type: "json_object" },
      messages: [
        { role: "system", content: system },
        { role: "user", content },
      ],
    }),
  });

  if (res.status === 429) throw new Error("RATE_LIMIT");
  if (res.status === 402) throw new Error("CREDITS_EXHAUSTED");
  if (!res.ok) {
    const t = await res.text();
    throw new Error(`AI grading failed (${res.status}): ${t.slice(0, 300)}`);
  }

  const data = await res.json();
  const raw = data.choices?.[0]?.message?.content ?? "{}";
  let parsed: GradeResult;
  try {
    parsed = JSON.parse(raw);
  } catch {
    const m = raw.match(/\{[\s\S]*\}/);
    parsed = m ? JSON.parse(m[0]) : { extracted_text: "", score: 0, feedback: "Could not parse grading.", criteria: [] };
  }
  const clamp = Math.max(0, Math.min(params.maxMarks, Number(parsed.score) || 0));
  return {
    extracted_text: parsed.extracted_text || "",
    score: clamp,
    feedback: parsed.feedback || "",
    criteria: Array.isArray(parsed.criteria) ? parsed.criteria : [],
  };
}

export const gradeSubmission = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ submissionId: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    const apiKey = process.env.LOVABLE_API_KEY;
    if (!apiKey) throw new Error("Missing LOVABLE_API_KEY");
    const { supabase } = context;

    const { data: submission, error: subErr } = await supabase
      .from("submissions")
      .select("id, exam_id")
      .eq("id", data.submissionId)
      .single();
    if (subErr || !submission) throw new Error("Submission not found");

    const { data: answers, error: ansErr } = await supabase
      .from("answers")
      .select(
        "id, answer_text, source_type, file_path, question:questions(id, prompt, model_answer, rubric, max_marks)",
      )
      .eq("submission_id", data.submissionId);
    if (ansErr) throw new Error(ansErr.message);

    await supabase
      .from("submissions")
      .update({ status: "grading" })
      .eq("id", data.submissionId);

    let total = 0;
    let maxTotal = 0;

    for (const a of answers ?? []) {
      const q = (a as { question: { id: string; prompt: string; model_answer: string | null; rubric: string | null; max_marks: number } | null }).question;
      if (!q) continue;
      const maxMarks = Number(q.max_marks) || 10;
      maxTotal += maxMarks;

      let fileData: { base64: string; mime: string } | undefined;
      if (a.source_type !== "typed" && a.file_path) {
        const { data: blob, error: dErr } = await supabase.storage
          .from("answer-sheets")
          .download(a.file_path);
        if (!dErr && blob) {
          const buf = Buffer.from(await blob.arrayBuffer());
          fileData = { base64: buf.toString("base64"), mime: mimeFromPath(a.file_path) };
        }
      }

      try {
        const result = await gradeAnswer(apiKey, {
          prompt: q.prompt,
          modelAnswer: q.model_answer,
          rubric: q.rubric,
          maxMarks,
          answerText: a.answer_text,
          fileData,
        });
        total += result.score;
        await supabase
          .from("answers")
          .update({
            extracted_text: result.extracted_text || a.answer_text,
            ai_score: result.score,
            final_score: result.score,
            ai_feedback: result.feedback,
            criteria_scores: JSON.parse(JSON.stringify(result.criteria)),
            overridden: false,
          })
          .eq("id", a.id);
      } catch (err) {
        if (err instanceof Error && (err.message === "RATE_LIMIT" || err.message === "CREDITS_EXHAUSTED")) {
          await supabase.from("submissions").update({ status: "pending" }).eq("id", data.submissionId);
          throw err;
        }
        await supabase
          .from("answers")
          .update({ ai_feedback: "Grading failed for this answer.", ai_score: 0, final_score: 0 })
          .eq("id", a.id);
      }
    }

    await supabase
      .from("submissions")
      .update({ status: "graded", total_score: total, max_total: maxTotal })
      .eq("id", data.submissionId);

    return { ok: true, total, maxTotal };
  });
