import { useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Bar, BarChart, ResponsiveContainer, XAxis, YAxis, Cell, Tooltip,
} from "recharts";

interface Submission {
  id: string;
  status: string;
  total_score: number | null;
  max_total: number | null;
}

export function ExamAnalytics({ submissions }: { submissions: Submission[] }) {
  const graded = useMemo(
    () => submissions.filter((s) => s.status === "graded" && s.total_score != null && s.max_total != null && s.max_total > 0),
    [submissions],
  );

  const stats = useMemo(() => {
    if (graded.length === 0) return null;
    const pcts = graded.map((s) => (Number(s.total_score) / Number(s.max_total)) * 100);
    const avg = pcts.reduce((a, b) => a + b, 0) / pcts.length;
    const high = Math.max(...pcts);
    const low = Math.min(...pcts);
    const passed = pcts.filter((p) => p >= 40).length;
    return { avg, high, low, passRate: (passed / pcts.length) * 100 };
  }, [graded]);

  const distribution = useMemo(() => {
    const buckets = [
      { name: "0-40%", count: 0 },
      { name: "40-60%", count: 0 },
      { name: "60-75%", count: 0 },
      { name: "75-90%", count: 0 },
      { name: "90-100%", count: 0 },
    ];
    graded.forEach((s) => {
      const p = (Number(s.total_score) / Number(s.max_total)) * 100;
      if (p < 40) buckets[0].count++;
      else if (p < 60) buckets[1].count++;
      else if (p < 75) buckets[2].count++;
      else if (p < 90) buckets[3].count++;
      else buckets[4].count++;
    });
    return buckets;
  }, [graded]);

  if (!stats) {
    return (
      <Card className="border-dashed">
        <CardContent className="py-12 text-center text-muted-foreground">
          Grade some submissions to see analytics.
        </CardContent>
      </Card>
    );
  }

  const cards = [
    { label: "Average", value: `${stats.avg.toFixed(1)}%` },
    { label: "Highest", value: `${stats.high.toFixed(0)}%` },
    { label: "Lowest", value: `${stats.low.toFixed(0)}%` },
    { label: "Pass rate (≥40%)", value: `${stats.passRate.toFixed(0)}%` },
  ];

  return (
    <div className="space-y-6">
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {cards.map((c) => (
          <Card key={c.label}>
            <CardContent className="p-5">
              <p className="text-sm text-muted-foreground">{c.label}</p>
              <p className="mt-1 font-serif text-3xl font-semibold text-foreground">{c.value}</p>
            </CardContent>
          </Card>
        ))}
      </div>
      <Card>
        <CardHeader><CardTitle className="font-serif text-lg">Score distribution</CardTitle></CardHeader>
        <CardContent>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={distribution}>
                <XAxis dataKey="name" stroke="var(--muted-foreground)" fontSize={12} tickLine={false} axisLine={false} />
                <YAxis allowDecimals={false} stroke="var(--muted-foreground)" fontSize={12} tickLine={false} axisLine={false} />
                <Tooltip
                  cursor={{ fill: "var(--secondary)" }}
                  contentStyle={{ background: "var(--card)", border: "1px solid var(--border)", borderRadius: 8, color: "var(--foreground)" }}
                />
                <Bar dataKey="count" radius={[6, 6, 0, 0]}>
                  {distribution.map((_, i) => (
                    <Cell key={i} fill="var(--accent)" />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
