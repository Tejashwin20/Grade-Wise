import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Upload, Type } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter, DialogDescription,
} from "@/components/ui/dialog";

interface Question {
  id: string;
  position: number;
  prompt: string;
  max_marks: number;
}

type Mode = "typed" | "upload";

export function AddSubmissionDialog({
  examId,
  questions,
}: {
  examId: string;
  questions: Question[];
}) {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [studentName, setStudentName] = useState("");
  const [studentRef, setStudentRef] = useState("");
  const [modes, setModes] = useState<Record<string, Mode>>({});
  const [texts, setTexts] = useState<Record<string, string>>({});
  const [files, setFiles] = useState<Record<string, File | null>>({});

  const reset = () => {
    setStudentName(""); setStudentRef(""); setModes({}); setTexts({}); setFiles({});
  };

  const modeFor = (id: string) => modes[id] ?? "typed";

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    if (questions.length === 0) {
      toast.error("Add at least one question first.");
      return;
    }
    setSaving(true);
    try {
      const { data: submission, error: subErr } = await supabase
        .from("submissions")
        .insert({ exam_id: examId, teacher_id: user.id, student_name: studentName, student_ref: studentRef, status: "pending" })
        .select("id")
        .single();
      if (subErr || !submission) throw new Error(subErr?.message || "Failed to create submission");

      for (const q of questions) {
        const mode = modeFor(q.id);
        let filePath: string | null = null;
        if (mode === "upload") {
          const file = files[q.id];
          if (file) {
            const ext = file.name.split(".").pop() || "dat";
            const path = `${user.id}/${submission.id}/${q.id}.${ext}`;
            const { error: upErr } = await supabase.storage
              .from("answer-sheets")
              .upload(path, file, { upsert: true });
            if (upErr) throw new Error(upErr.message);
            filePath = path;
          }
        }
        const { error: ansErr } = await supabase.from("answers").insert({
          submission_id: submission.id,
          question_id: q.id,
          source_type: mode === "upload" ? "file" : "typed",
          answer_text: mode === "typed" ? texts[q.id] || "" : null,
          file_path: filePath,
        });
        if (ansErr) throw new Error(ansErr.message);
      }

      toast.success("Submission added.");
      setOpen(false);
      reset();
      queryClient.invalidateQueries({ queryKey: ["submissions", examId] });
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Something went wrong");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={(o) => { setOpen(o); if (!o) reset(); }}>
      <DialogTrigger asChild>
        <Button>Add submission</Button>
      </DialogTrigger>
      <DialogContent className="max-h-[85vh] overflow-y-auto sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle>Add a student submission</DialogTitle>
          <DialogDescription>
            Enter the student's answers as text, or upload a photo / PDF of a handwritten sheet.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={submit} className="space-y-5">
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-1.5">
              <Label htmlFor="sn">Student name</Label>
              <Input id="sn" required value={studentName} onChange={(e) => setStudentName(e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="sr">Student ID / roll no.</Label>
              <Input id="sr" value={studentRef} onChange={(e) => setStudentRef(e.target.value)} />
            </div>
          </div>

          <div className="space-y-4">
            {questions.map((q, i) => {
              const mode = modeFor(q.id);
              return (
                <div key={q.id} className="rounded-lg border border-border p-4">
                  <div className="mb-3 flex items-start justify-between gap-3">
                    <p className="text-sm font-medium">
                      <span className="text-muted-foreground">Q{i + 1}.</span> {q.prompt}
                    </p>
                    <div className="flex shrink-0 rounded-md border border-border p-0.5">
                      <button type="button" onClick={() => setModes((m) => ({ ...m, [q.id]: "typed" }))}
                        className={`flex items-center gap-1 rounded px-2 py-1 text-xs ${mode === "typed" ? "bg-primary text-primary-foreground" : "text-muted-foreground"}`}>
                        <Type className="h-3 w-3" /> Text
                      </button>
                      <button type="button" onClick={() => setModes((m) => ({ ...m, [q.id]: "upload" }))}
                        className={`flex items-center gap-1 rounded px-2 py-1 text-xs ${mode === "upload" ? "bg-primary text-primary-foreground" : "text-muted-foreground"}`}>
                        <Upload className="h-3 w-3" /> Upload
                      </button>
                    </div>
                  </div>
                  {mode === "typed" ? (
                    <Textarea
                      rows={3}
                      placeholder="Student's answer…"
                      value={texts[q.id] || ""}
                      onChange={(e) => setTexts((t) => ({ ...t, [q.id]: e.target.value }))}
                    />
                  ) : (
                    <Input
                      type="file"
                      accept="image/png,image/jpeg,image/webp,application/pdf"
                      onChange={(e) => setFiles((f) => ({ ...f, [q.id]: e.target.files?.[0] ?? null }))}
                    />
                  )}
                </div>
              );
            })}
          </div>

          <DialogFooter>
            <Button type="submit" disabled={saving}>{saving ? "Saving…" : "Save submission"}</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
