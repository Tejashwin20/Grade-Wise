import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter, DialogDescription,
} from "@/components/ui/dialog";

export interface QuestionData {
  id?: string;
  prompt: string;
  model_answer: string | null;
  rubric: string | null;
  max_marks: number;
}

export function QuestionDialog({
  examId,
  question,
  position,
  trigger,
}: {
  examId: string;
  question?: QuestionData;
  position: number;
  trigger: React.ReactNode;
}) {
  const queryClient = useQueryClient();
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [prompt, setPrompt] = useState(question?.prompt ?? "");
  const [modelAnswer, setModelAnswer] = useState(question?.model_answer ?? "");
  const [rubric, setRubric] = useState(question?.rubric ?? "");
  const [maxMarks, setMaxMarks] = useState(String(question?.max_marks ?? 10));

  const save = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    const payload = {
      exam_id: examId,
      prompt,
      model_answer: modelAnswer,
      rubric,
      max_marks: Number(maxMarks) || 0,
      position,
    };
    const { error } = question?.id
      ? await supabase.from("questions").update(payload).eq("id", question.id)
      : await supabase.from("questions").insert(payload);
    setSaving(false);
    if (error) return toast.error(error.message);
    setOpen(false);
    queryClient.invalidateQueries({ queryKey: ["questions", examId] });
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>{trigger}</DialogTrigger>
      <DialogContent className="max-h-[85vh] overflow-y-auto sm:max-w-xl">
        <DialogHeader>
          <DialogTitle>{question?.id ? "Edit question" : "Add question"}</DialogTitle>
          <DialogDescription>
            Provide a model answer and rubric so the AI grades fairly and consistently.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={save} className="space-y-4">
          <div className="space-y-1.5">
            <Label htmlFor="q-prompt">Question</Label>
            <Textarea id="q-prompt" required rows={2} value={prompt} onChange={(e) => setPrompt(e.target.value)} />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="q-model">Model answer</Label>
            <Textarea id="q-model" rows={4} value={modelAnswer} onChange={(e) => setModelAnswer(e.target.value)} placeholder="The ideal/reference answer" />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="q-rubric">Rubric / marking criteria</Label>
            <Textarea id="q-rubric" rows={4} value={rubric} onChange={(e) => setRubric(e.target.value)} placeholder="e.g. Definition (3), Example (3), Explanation (4)" />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="q-marks">Maximum marks</Label>
            <Input id="q-marks" type="number" min={1} step="0.5" required value={maxMarks} onChange={(e) => setMaxMarks(e.target.value)} className="w-32" />
          </div>
          <DialogFooter>
            <Button type="submit" disabled={saving}>{saving ? "Saving…" : "Save question"}</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
