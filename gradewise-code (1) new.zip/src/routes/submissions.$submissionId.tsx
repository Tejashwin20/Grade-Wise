import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { ArrowLeft, Sparkles, Check, FileText } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import { gradeSubmission } from "@/lib/grading.functions";
import { AppShell } from "@/components/app-shell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";

export const Route = createFileRoute("/submissions/$submissionId")({
  component: SubmissionReview,
});

interface Criterion { name: string; score: number; max: number; comment: string }

function SubmissionReview() {
  const { submissionId } = Route.useParams();
  const { user, loading } = useAuth();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const gradeFn = useServerFn(gradeSubmission);
  const [grading, setGrading] = useState(false);
  const [overrides, setOverrides] = useState<Record<string, string>>({});

  useEffect(() => {
    if (!loading && !user) navigate({ to: "/auth" });
  }, [user, loading, navigate]);

  const { data: submission } = useQuery({
    queryKey: ["submission", submissionId],
    enabled: !!user,
    queryFn: async () => {
      const { data, error } = await supabase.from("submissions").select("*").eq("id", submissionId).single();
      if (error) throw error;
      return data;
    },
  });

  const { data: answers } = useQuery({
    queryKey: ["answers", submissionId],
    enabled: !!user,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("answers")
        .select("*, question:questions(id, prompt, max_marks, model_answer, position)")
        .eq("submission_id", submissionId);
      if (error) throw error;
      return (data ?? []).sort(
        (a, b) => ((a.question as { position: number } | null)?.position ?? 0) - ((b.question as { position: number } | null)?.position ?? 0),
      );
    },
  });

  const runGrading = async () => {
    setGrading(true);
    try {
      await gradeFn({ data: { submissionId } });
      toast.success("Grading complete.");
      queryClient.invalidateQueries({ queryKey: ["answers", submissionId] });
      queryClient.invalidateQueries({ queryKey: ["submission", submissionId] });
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Grading failed";
      if (msg.includes("RATE_LIMIT")) toast.error("AI is rate limited. Please try again shortly.");
      else if (msg.includes("CREDITS_EXHAUSTED")) toast.error("AI credits exhausted. Add credits to continue.");
      else toast.error(msg);
    } finally {
      setGrading(false);
    }
  };

  const saveOverride = async (answerId: string, maxMarks: number) => {
    const val = Number(overrides[answerId]);
    if (Number.isNaN(val) || val < 0 || val > maxMarks) {
      toast.error(`Enter a score between 0 and ${maxMarks}.`);
      return;
    }
    const { error } = await supabase
      .from("answers")
      .update({ final_score: val, overridden: true })
      .eq("id", answerId);
    if (error) return toast.error(error.message);

    const { data: all } = await supabase.from("answers").select("final_score").eq("submission_id", submissionId);
    const total = (all ?? []).reduce((sum, a) => sum + (Number(a.final_score) || 0), 0);
    await supabase.from("submissions").update({ total_score: total }).eq("id", submissionId);

    toast.success("Mark updated.");
    setOverrides((o) => { const n = { ...o }; delete n[answerId]; return n; });
    queryClient.invalidateQueries({ queryKey: ["answers", submissionId] });
    queryClient.invalidateQueries({ queryKey: ["submission", submissionId] });
  };

  const isGraded = submission?.status === "graded";

  return (
    <AppShell>
      {submission && (
        <Link to="/exams/$examId" params={{ examId: submission.exam_id }} className="mb-4 inline-flex items-center text-sm text-muted-foreground hover:text-foreground">
          <ArrowLeft className="mr-1 h-4 w-4" /> Back to exam
        </Link>
      )}

      <div className="mb-6 flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="font-serif text-3xl font-semibold text-foreground">{submission?.student_name}</h1>
          {submission?.student_ref && <p className="text-muted-foreground">{submission.student_ref}</p>}
          {submission?.total_score != null && submission?.max_total != null && (
            <p className="mt-2 text-lg">
              <span className="font-serif text-2xl font-semibold text-accent-foreground">{Number(submission.total_score)}</span>
              <span className="text-muted-foreground"> / {Number(submission.max_total)}</span>
            </p>
          )}
        </div>
        <Button onClick={runGrading} disabled={grading}>
          <Sparkles className="mr-1.5 h-4 w-4" />
          {grading ? "Grading…" : isGraded ? "Re-grade with AI" : "Grade with AI"}
        </Button>
      </div>

      <div className="space-y-5">
        {(answers ?? []).map((a, i) => {
          const q = a.question as { id: string; prompt: string; max_marks: number } | null;
          const maxMarks = Number(q?.max_marks ?? 0);
          const criteria = (a.criteria_scores as Criterion[] | null) ?? [];
          return (
            <Card key={a.id}>
              <CardHeader>
                <div className="flex items-start justify-between gap-4">
                  <CardTitle className="font-serif text-lg">
                    <span className="text-muted-foreground">Q{i + 1}.</span> {q?.prompt}
                  </CardTitle>
                  <div className="flex shrink-0 items-center gap-2">
                    {a.overridden && <Badge variant="secondary">Overridden</Badge>}
                    <Badge className="bg-primary text-primary-foreground">
                      {a.final_score != null ? Number(a.final_score) : "—"} / {maxMarks}
                    </Badge>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <p className="mb-1 flex items-center gap-1.5 text-xs font-medium uppercase tracking-wide text-muted-foreground">
                    <FileText className="h-3.5 w-3.5" />
                    {a.source_type === "typed" ? "Answer" : "Transcribed answer"}
                  </p>
                  <p className="whitespace-pre-wrap rounded-lg bg-secondary p-3 text-sm">
                    {a.extracted_text || a.answer_text || <span className="text-muted-foreground">No answer yet — run grading to transcribe.</span>}
                  </p>
                </div>

                {a.ai_feedback && (
                  <div>
                    <p className="mb-1 text-xs font-medium uppercase tracking-wide text-muted-foreground">AI feedback</p>
                    <p className="rounded-lg border border-accent/30 bg-accent/10 p-3 text-sm">{a.ai_feedback}</p>
                  </div>
                )}

                {criteria.length > 0 && (
                  <div className="space-y-2">
                    <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">Rubric breakdown</p>
                    {criteria.map((c, ci) => (
                      <div key={ci} className="flex items-start justify-between gap-3 rounded-md border border-border px-3 py-2 text-sm">
                        <div>
                          <span className="font-medium">{c.name}</span>
                          {c.comment && <p className="text-muted-foreground">{c.comment}</p>}
                        </div>
                        <span className="shrink-0 font-medium">{c.score} / {c.max}</span>
                      </div>
                    ))}
                  </div>
                )}

                <Separator />
                <div className="flex items-center gap-2">
                  <span className="text-sm text-muted-foreground">Override mark:</span>
                  <Input
                    type="number" min={0} max={maxMarks} step="0.5"
                    className="w-24"
                    placeholder={a.final_score != null ? String(Number(a.final_score)) : "0"}
                    value={overrides[a.id] ?? ""}
                    onChange={(e) => setOverrides((o) => ({ ...o, [a.id]: e.target.value }))}
                  />
                  <Button size="sm" variant="outline" onClick={() => saveOverride(a.id, maxMarks)}>
                    <Check className="mr-1 h-4 w-4" /> Save
                  </Button>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </AppShell>
  );
}
