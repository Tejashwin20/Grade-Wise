import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useEffect } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { ArrowLeft, Pencil, Plus, Trash2, ClipboardList } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import { AppShell } from "@/components/app-shell";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { QuestionDialog } from "@/components/question-dialog";
import { AddSubmissionDialog } from "@/components/add-submission-dialog";
import { ExamAnalytics } from "@/components/exam-analytics";

export const Route = createFileRoute("/exams/$examId")({
  component: ExamDetail,
});

const statusStyles: Record<string, string> = {
  pending: "bg-secondary text-secondary-foreground",
  grading: "bg-accent/20 text-accent-foreground",
  graded: "bg-success/15 text-success",
};

function ExamDetail() {
  const { examId } = Route.useParams();
  const { user, loading } = useAuth();
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  useEffect(() => {
    if (!loading && !user) navigate({ to: "/auth" });
  }, [user, loading, navigate]);

  const { data: exam } = useQuery({
    queryKey: ["exam", examId],
    enabled: !!user,
    queryFn: async () => {
      const { data, error } = await supabase.from("exams").select("*").eq("id", examId).single();
      if (error) throw error;
      return data;
    },
  });

  const { data: questions } = useQuery({
    queryKey: ["questions", examId],
    enabled: !!user,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("questions").select("*").eq("exam_id", examId).order("position");
      if (error) throw error;
      return data;
    },
  });

  const { data: submissions } = useQuery({
    queryKey: ["submissions", examId],
    enabled: !!user,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("submissions").select("*").eq("exam_id", examId).order("created_at", { ascending: false });
      if (error) throw error;
      return data;
    },
  });

  const deleteQuestion = async (id: string) => {
    const { error } = await supabase.from("questions").delete().eq("id", id);
    if (error) return toast.error(error.message);
    queryClient.invalidateQueries({ queryKey: ["questions", examId] });
  };

  const nextPosition = questions?.length ?? 0;

  return (
    <AppShell>
      <Link to="/" className="mb-4 inline-flex items-center text-sm text-muted-foreground hover:text-foreground">
        <ArrowLeft className="mr-1 h-4 w-4" /> All exams
      </Link>

      <div className="mb-6">
        {exam?.subject && <p className="text-xs font-medium uppercase tracking-wide text-accent">{exam.subject}</p>}
        <h1 className="font-serif text-3xl font-semibold text-foreground">{exam?.title ?? "Exam"}</h1>
        {exam?.description && <p className="mt-1 text-muted-foreground">{exam.description}</p>}
      </div>

      <Tabs defaultValue="questions">
        <TabsList>
          <TabsTrigger value="questions">Questions ({questions?.length ?? 0})</TabsTrigger>
          <TabsTrigger value="submissions">Submissions ({submissions?.length ?? 0})</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
        </TabsList>

        {/* QUESTIONS */}
        <TabsContent value="questions" className="space-y-4">
          <div className="flex justify-end">
            <QuestionDialog
              examId={examId}
              position={nextPosition}
              trigger={<Button><Plus className="mr-1.5 h-4 w-4" /> Add question</Button>}
            />
          </div>
          {!questions || questions.length === 0 ? (
            <Card className="border-dashed"><CardContent className="py-12 text-center text-muted-foreground">
              No questions yet. Add one to define what students are graded on.
            </CardContent></Card>
          ) : (
            questions.map((q, i) => (
              <Card key={q.id}>
                <CardContent className="p-5">
                  <div className="flex items-start justify-between gap-4">
                    <div className="min-w-0">
                      <p className="font-medium">
                        <span className="text-muted-foreground">Q{i + 1}.</span> {q.prompt}
                      </p>
                      {q.model_answer && (
                        <p className="mt-2 line-clamp-2 text-sm text-muted-foreground">
                          <span className="font-medium text-foreground">Model:</span> {q.model_answer}
                        </p>
                      )}
                      {q.rubric && (
                        <p className="mt-1 line-clamp-2 text-sm text-muted-foreground">
                          <span className="font-medium text-foreground">Rubric:</span> {q.rubric}
                        </p>
                      )}
                    </div>
                    <div className="flex shrink-0 items-center gap-2">
                      <Badge variant="secondary">{Number(q.max_marks)} marks</Badge>
                      <QuestionDialog
                        examId={examId}
                        position={i}
                        question={{ id: q.id, prompt: q.prompt, model_answer: q.model_answer, rubric: q.rubric, max_marks: Number(q.max_marks) }}
                        trigger={<Button variant="ghost" size="icon"><Pencil className="h-4 w-4" /></Button>}
                      />
                      <Button variant="ghost" size="icon" onClick={() => deleteQuestion(q.id)}>
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </TabsContent>

        {/* SUBMISSIONS */}
        <TabsContent value="submissions" className="space-y-4">
          <div className="flex justify-end">
            <AddSubmissionDialog examId={examId} questions={(questions ?? []).map((q) => ({ id: q.id, position: q.position, prompt: q.prompt, max_marks: Number(q.max_marks) }))} />
          </div>
          {!submissions || submissions.length === 0 ? (
            <Card className="border-dashed"><CardContent className="flex flex-col items-center gap-2 py-12 text-center text-muted-foreground">
              <ClipboardList className="h-6 w-6" />
              No submissions yet.
            </CardContent></Card>
          ) : (
            <div className="overflow-hidden rounded-lg border border-border">
              <table className="w-full text-sm">
                <thead className="bg-secondary text-left text-muted-foreground">
                  <tr>
                    <th className="px-4 py-3 font-medium">Student</th>
                    <th className="px-4 py-3 font-medium">Status</th>
                    <th className="px-4 py-3 font-medium">Score</th>
                    <th className="px-4 py-3"></th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border bg-card">
                  {submissions.map((s) => (
                    <tr key={s.id} className="hover:bg-secondary/50">
                      <td className="px-4 py-3">
                        <div className="font-medium">{s.student_name}</div>
                        {s.student_ref && <div className="text-xs text-muted-foreground">{s.student_ref}</div>}
                      </td>
                      <td className="px-4 py-3">
                        <span className={`rounded-full px-2.5 py-0.5 text-xs font-medium capitalize ${statusStyles[s.status] ?? "bg-secondary"}`}>
                          {s.status}
                        </span>
                      </td>
                      <td className="px-4 py-3 font-medium">
                        {s.total_score != null && s.max_total != null
                          ? `${Number(s.total_score)} / ${Number(s.max_total)}`
                          : "—"}
                      </td>
                      <td className="px-4 py-3 text-right">
                        <Link to="/submissions/$submissionId" params={{ submissionId: s.id }}>
                          <Button variant="outline" size="sm">Review</Button>
                        </Link>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </TabsContent>

        {/* ANALYTICS */}
        <TabsContent value="analytics">
          <ExamAnalytics submissions={submissions ?? []} />
        </TabsContent>
      </Tabs>
    </AppShell>
  );
}
